// This program is free software: you can use, modify and/or redistribute it
// under the terms of the simplified BSD License. You should have received a
// copy of this license along this program. If not, see
// <http://www.opensource.org/licenses/bsd-license.html>.
//
// Copyright (C) 2017 Zhaoyi Meng <mzhy@ucla.edu>
// All rights reserved.

#include<iostream>
#include<fstream>
#include<cmath>
#include<cstdlib>
#include "MBO_S.h"
#include "Nystrom.h"
#include <string>
#include <vector>
#include "FeatureVec.h"
extern "C" {
#include "iio.h"
}
using namespace std;


int main(int argc, char * argv[]){
    if (argc<6) {
        cout << "Not enough input parameters"<<endl;
        printf("Usage: %s n dt mu sigma input_image_string input_fidelity_string\n", argv[0]);
    } else {
        int n = atoi(argv[1]);
        double dt = atof(argv[2]);
        double mu = atof(argv[3])*100.0;
        double sigma = atof(argv[4]);
        string input_image_string(argv[5]);
        string input_fidelity_string;
        bool has_fidelity = false;
        
        if (argc==7) {
            input_fidelity_string = argv[6];
            has_fidelity = true;
        }
        double iterNum= 500;
        int s=3;
        int m = 100;                                    // number of leading eigenvectors
        //read image using the iio library
        int width;
        int height;
        int d;

        ifstream infile(input_image_string.c_str());       
	ifstream infile2(input_fidelity_string.c_str());
 	if ((!infile.good()) || (!infile2.good())) {
            cout << "Error Opening File"<<endl;
            return 0;
        }
        
        double * input_image;
        input_image = iio_read_image_double_vec(input_image_string.c_str(),
                                                &width,&height,&d);

       // add a small number to all the pixel values in case there are a lot of 0s
        for (int i=0; i<width*height*d; i++) {
            input_image[i] += 0.1;
        }
        double * feature_vec;
  
        // if the number of channels of the image is small, we use the nonlocal means method
        // to build the feature vector of each pixel.
        if (d<4) {
            // for RGB image, rescale some parameters, so that it is
            // more consistent with the hyperspectral images
            sigma = sigma*100.0;
            mu = mu*10.0;
            // for RGB image, need to read frame by frame
            double * input_image_split = new double [width*height*d];
            
            for (int i=0; i<width*height; i++) {
                for (int l=0; l<d; l++) {
                    input_image_split[width*height*l+i] = input_image[d*i+l];
                }
            }
            // use non-local means method to build the feature vector
            int windowSize = 2;
            FeatureVec Feature_obj;
            
            double * kernel = new double[(2*windowSize+1)*(2*windowSize+1)];
            for (int i=0; i<(2*windowSize+1)*(2*windowSize+1); i++) {
                kernel[i] = 0;
            }
            Feature_obj.makeKernel(kernel,windowSize);
            
            int N1p = height + 2 * windowSize;
            int N2p = width + 2 * windowSize;
            double* padimage = new double[N1p*N2p*d];
            for (int i=0; i<N1p*N2p*d; i++) {
                padimage[i] = 0;
            }
            Feature_obj.padarray(input_image_split,padimage,
                                 windowSize,height,width,d);
            
            int size_feature = width*height*(2*windowSize+1)*(2*windowSize+1)*d;
            feature_vec = new double[size_feature];
            
            Feature_obj.makeFeatureVec(feature_vec,padimage,kernel,
                                       windowSize,height,width,d);
            
            d = (2*windowSize+1)*(2*windowSize+1)*d;
            delete [] kernel;
            delete [] input_image_split;
            delete [] padimage;
        } else {
            cout << "Hyperspectral Image"<<endl;
            feature_vec = input_image;
        }
        
        int N = width*height;
        // input fidelity
        int width_f;
        int height_f;
        int d_f;
        vector<double> fidelity_vec;
        
        if (has_fidelity) {
            double * fidelity_full = iio_read_image_double_vec(
                input_fidelity_string.c_str(),&width_f,&height_f,&d_f); 
	    if (d_f!=1 || width_f!=width || height_f!=height) {
            	cout << "Wrong dimension of fidelity"<<endl;
		return 0;
	    }	
	    for (int i=0; i<width_f*height_f*d_f; i++) {
                if (fidelity_full[i] != 0) {
                    fidelity_vec.push_back(i+1);
                    fidelity_vec.push_back(fidelity_full[i] -1);
                }
            }
        } else {
            cout << "Lack fidelity"<<endl;
        }
        
        int rows_fidelity = fidelity_vec.size()/2;
        double * fidelity = &fidelity_vec[0];

        //Nystrom
        cout << "start Nystrom"<<endl;
        double * X = new double [N*m];               // Eigenvectors of Ls
        double * D = new double [m];                 // Eigenvalues of Ls
        Nystrom N_obj;
        N_obj.Nystrom_algorithm(feature_vec,m,sigma,N,d,X,D);
        cout << "end Nystrom"<<endl;
        //semi-supervised MBO algorithm
        cout << "start semi-supervised MBO"<<endl;
        MBO_S mbo_object;
        double * index = new double[N];
        mbo_object.MBO_algorithm(index, X, D, fidelity,
                                 N, n, rows_fidelity, m,s, dt, mu,iterNum);
        cout << "end semi-supervised MBO"<<endl;

        ofstream final;
        final.open("classification_result.txt");
        for (int i=0; i<N; i++) {
            final << index[i] << "\r\n";
        }
        final<<"\r\n\n";
        
        // Free momeries
        delete [] X;
        delete [] D;
        delete [] input_image;
	if (d<4) {
      	  delete [] feature_vec;
        }
   }
    return 0;
}
